package com.example.philipandrean.utsmdp;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.example.philipandrean.utsmdp.Order;
import com.example.philipandrean.utsmdp.R;

import java.util.ArrayList;

public class OrderAdapter extends ArrayAdapter<Order>{
    private Context context;
    private ArrayList<Order> data = new ArrayList<>();
    public OrderAdapter(Context context , ArrayList<Order> data){
        super(context , R.layout.row_item_order,data);
        this.context = context;
        this.data = data;
    }

    @Nullable
    @Override
    public Order getItem(int position){
        return data.get(position);

    }
    @NonNull
    @Override
    public View getView(int position , @Nullable View convertView , @NonNull ViewGroup parent){
        return convertView;
    }

}