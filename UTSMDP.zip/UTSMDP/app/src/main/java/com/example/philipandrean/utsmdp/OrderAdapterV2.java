
package com.example.philipandrean.utsmdp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class OrderAdapterV2 extends RecyclerView.Adapter<OrderAdapterV2.ViewHolder> {
    private ArrayList<Order> menulist;

    public OrderAdapterV2(ArrayList<Order> menulist) {
        this.menulist = menulist;
    }

    @Override
    public OrderAdapterV2.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View v = inflater.inflate(R.layout.row_item_order,viewGroup,false);
        return new ViewHolder(v);//generate ViewHolder
    }

    @Override
    public void onBindViewHolder(OrderAdapterV2.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}

